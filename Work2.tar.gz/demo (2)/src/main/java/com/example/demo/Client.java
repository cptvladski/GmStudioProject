package com.example.demo;

import java.lang.management.ManagementFactory;

import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;


@SpringBootApplication
@EnableAutoConfiguration
public class Client {
	@Configuration
	public static class SecurityPermitAllConfig extends WebSecurityConfigurerAdapter {
	    @Override
	    protected void configure(HttpSecurity http) throws Exception {
	        http.authorizeRequests().anyRequest().permitAll()  
	            .and().csrf().disable();
	    }
	}
	@Endpoint(id = "custom") 
	public class CustomEndpoint { 
		@ReadOperation 
		public String getHello(){ 
			return new Long(Math.round(100 * Math.random())).toString(); 
			} 
		}

	@Bean public CustomEndpoint customEndpoint() { return new CustomEndpoint(); }
	public static void main(String[] args) {
		MBeanServer server = ManagementFactory.getPlatformMBeanServer();
		ObjectName objectName = null;
		try {
		    objectName = new ObjectName("com.example.demo:type=basic,name=test");
		} catch (MalformedObjectNameException e) {
		    e.printStackTrace();
		}
		SpringApplication.run(Client.class, args);
	}

}


