package com.example.demo;

public interface TestMBean {
	public String test1();
	public void test2(String str);
}
