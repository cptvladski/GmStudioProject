package com.example.demo;

public class Test implements TestMBean {

	@Override
	public String test1() {
		return "test" + new Long(Math.round(100 * Math.random())).toString();
	}

	@Override
	public void test2(String str) {
		System.out.println(str + new Long(Math.round(100 * Math.random())).toString());

	}

}
